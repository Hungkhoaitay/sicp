sum_cubes(3, 7);
