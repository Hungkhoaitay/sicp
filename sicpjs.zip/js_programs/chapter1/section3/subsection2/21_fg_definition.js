function f(g) {
   return g(2);
}
