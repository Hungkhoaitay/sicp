integral(cube, 0, 1, 0.01);
