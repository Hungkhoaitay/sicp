function cube(x) {
    return x * x * x;
}
cube(3);

// expected: 27
