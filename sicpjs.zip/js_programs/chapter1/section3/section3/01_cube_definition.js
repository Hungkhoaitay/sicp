function cube(x) {
    return x * x * x;
}

cube(3);
