// compose to be written by student; see EXERCISE 1.42
