// chapter=3 variant=non-det 
const prepositions = list("prep", "for", "to",  "in", "by", "with");
