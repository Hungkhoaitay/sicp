// functions from SICP JS 4.3.3
