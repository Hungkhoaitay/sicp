function is_tagged_list(component, the_tag) {
    return is_pair(component) && head(component) === the_tag;
}
function is_name(component) {
    return is_tagged_list(component, "name");
}
function index_key_of(pat) {
    return(head(pat));
}

parse_query_verbose('assert(                           \
rule(append_to_form(null, y, y)))                ', "verbose");
parse_query_verbose('assert(                           \
rule(append_to_form(pair(u, v), y, pair(u, z)),  \
     append_to_form(v, y, z)))                   ', "verbose");

first_answer('append_to_form(x, y, list("a", "b", "c", "d"))');
// parse_query_verbose('append_to_form(x, y, list("a", "b", "c", "d"))', "");
