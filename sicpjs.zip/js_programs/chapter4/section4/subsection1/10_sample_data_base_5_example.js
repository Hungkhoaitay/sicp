first_answer('job(x, pair("accounting", y))');
