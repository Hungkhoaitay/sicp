first_answer('job(x, pair("computer", $type))');
