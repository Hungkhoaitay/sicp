first_answer('lives_near(list("Reasoner", "Louis"), who)');
