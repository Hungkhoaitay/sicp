first_answer('can_do_job(list(x, "assistant"), y)');
