const my_assignment_statement = parse("x = 1;");
assignment_symbol(my_assignment_statement);
assignment_value_expression(my_assignment_statement);
